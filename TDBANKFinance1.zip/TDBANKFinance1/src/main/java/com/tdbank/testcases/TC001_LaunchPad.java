package com.tdbank.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.tdbank.pages.HomePage;
import com.tdbank.pages.LaunchpadPage;
import com.tdbank.pages.LoginPage;
import com.tdbank.testng.api.base.ProjectSpecificMethods;

public class TC001_LaunchPad extends ProjectSpecificMethods{

	@BeforeTest
	public void setData() {
		testCaseName="TC001_LaunchPad";
		testDescription="Submit the Launchpad";
		nodes = "Leads";		
		dataSheetName="Launchpad";
		category="Regression";
		authors="Giri";
	}

	@Test(dataProvider="fetchData")
	public void submitLP(
			String USERNAME, String PASSWORD, String LOGINNAME, String CONTEXT, String NAME
			, String Q1dot1, String Q3dot0, String addlncomment
			)throws InterruptedException{

		new LoginPage(driver, node, test)
		.enterUserName(USERNAME)
		.enterPassword(PASSWORD)
		.clickLogin();
		
		new HomePage(driver, node, test)
		.verifyLoggedName(LOGINNAME)
		.clickALLEval()
		.enterContext(CONTEXT)
		.enterName(NAME)	
		.clickViewButton();
		
		new LaunchpadPage(driver, node, test)
		.enterQ1dot1Response(Q1dot1)
		.getRiskRating()
		.getCARating()
		.getCAStatus()
		.getLastCompletedDate()
		.clickQ3dot0Response(Q3dot0)
		.enterAdditionalNotes(addlncomment);
		//.clickLPSubmit();
		
					
	}
}
