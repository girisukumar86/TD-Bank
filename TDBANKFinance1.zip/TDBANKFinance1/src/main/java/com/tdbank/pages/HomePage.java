package com.tdbank.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.tdbank.testng.api.base.ProjectSpecificMethods;

import cucumber.api.java.en.Then;

public class HomePage extends ProjectSpecificMethods{

	public HomePage(RemoteWebDriver driver, ExtentTest node, ExtentTest test){
		this.driver = driver;
		this.node = node;
		this.test = test;
		PageFactory.initElements(driver, this);
	}		

	@FindBy(how=How.XPATH,using="(//a[@href='#'])[1]")
	public WebElement eleLoggedName;

	public HomePage verifyLoggedName(String LOGINNAME) {
		verifyPartialText(eleLoggedName, LOGINNAME);
		return this;
	}
	
	//Click Show me All under Evaluations
	@FindBy(how=How.XPATH,using="(//div[@class='hiperos_localizable'])[1]")
	public WebElement eleAllEvaluationsLink;

	public HomePage clickALLEval(){
		click(eleAllEvaluationsLink);
		return this;
	}

	@FindBy(how = How.XPATH, using = "(//input[@class='k-input'])[4]")
	public WebElement eleContext;
	
	public HomePage enterContext(String CONTEXT) throws InterruptedException {
		TypeAndEnter(eleContext, CONTEXT);
		return this;
	}	
	
	@FindBy(how = How.XPATH, using = "(//input[@class='k-input'])[1]")
	WebElement eleName;
	
	public HomePage enterName(String NAME) throws InterruptedException {
		TypeAndEnter(eleName, NAME);
		return this;
	}
	
	@FindBy(how = How.XPATH, using = "(//a[@class='btn btn-primary'])[1]")
	WebElement eleViewButton;
	
	public LaunchpadPage clickViewButton() {
		click(eleViewButton);
		return new LaunchpadPage(driver, node, test);
	}
	/*@FindBy(how=How.CLASS_NAME,using="decorativeSubmit")
	private WebElement eleLogOut;
	
	public LoginPage clickLogout() {
		click(eleLogOut);
		return new LoginPage(driver, node, test);

	}*/
	
	

}










