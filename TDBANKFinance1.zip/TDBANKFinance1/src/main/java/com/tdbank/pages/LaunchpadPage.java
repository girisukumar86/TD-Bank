package com.tdbank.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;
import com.tdbank.testng.api.base.ProjectSpecificMethods;


public class LaunchpadPage extends ProjectSpecificMethods {


	public LaunchpadPage(RemoteWebDriver driver, ExtentTest node, ExtentTest test){
		this.driver = driver;
		this.node = node;
		this.test = test;
		PageFactory.initElements(driver, this);		
	}

	//Q1.1
	@FindBy(how = How.XPATH, using = "//*[text()[normalize-space()='1.1']]/following::select")
	private WebElement eleQ1dot1;
	
	public LaunchpadPage enterQ1dot1Response(String Q1dot1) throws InterruptedException{
		selectDropDownUsingVisibletext(eleQ1dot1, Q1dot1);
		Thread.sleep(2000);
		return this;
	}

	//Q2.0
		@FindBy(how = How.XPATH, using = "//div[contains(text(),'Risk Rating')]/following::div")
		private WebElement eleQ2dot0_1;
		public LaunchpadPage  getRiskRating() {
			getElementText(eleQ2dot0_1);
			takeSnap();
			return this;
		}
		@FindBy(how = How.XPATH, using = "//*[text()[normalize-space()='2.0']]/following::td[2]")
		private WebElement eleQ2dot0_2;
		public LaunchpadPage  getCARating() {
			getElementText(eleQ2dot0_2);
			takeSnap();
			return this;
			
		}
		@FindBy(how = How.XPATH, using = "//*[text()[normalize-space()='2.0']]/following::td[4]")
		private WebElement eleQ2dot0_3;
		public LaunchpadPage  getCAStatus() {
			getElementText(eleQ2dot0_3);
			return this;
			
		}
		@FindBy(how = How.XPATH, using = "//*[text()[normalize-space()='2.0']]/following::td[6]")
		private WebElement eleQ2dot0_4;	
		public LaunchpadPage  getLastCompletedDate() {
			getElementText(eleQ2dot0_4);
			return this;
			 
		}
		
		
		//Q3.0
		public LaunchpadPage clickQ3dot0Response(String Q3dot0) throws InterruptedException {
			WebElement eleQ3dot0_1 = driver.findElementByXPath("//*[text()[normalize-space()='3.0']]/following::input["+Q3dot0+"]");
			click(eleQ3dot0_1);
			Thread.sleep(5000);
			return this;
			
		}	
		
		//Q3.0
		@FindBy(how = How.XPATH, using = "//*[text()[normalize-space()='3.0']]/following::textarea")
		WebElement eleQ3dot0_2;
		
		public LaunchpadPage enterAdditionalNotes(String addlncomment) throws InterruptedException{
			clearAndType(eleQ3dot0_2, addlncomment);
			Thread.sleep(2000);
			return this;
		}
		
		
	

	

	@FindBy(how = How.XPATH, using = "//button[@id='btnFloatInitiateSubmit']")
	WebElement LPsubmit;
	public HomePage clickLPSubmit(){
		click(LPsubmit);
		return new HomePage(driver, node, test);
	}
	
	
}
