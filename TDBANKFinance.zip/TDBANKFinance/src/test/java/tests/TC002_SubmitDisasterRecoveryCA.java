package tests;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import libraries.PSF_CA;
import pages.CAPart1;
import pages.CAPart2;
import pages.CAPart3;
import pages.Compliance_CA;
import pages.DisasterRecovery_CA;

public class TC002_SubmitDisasterRecoveryCA extends PSF_CA{
	
	@BeforeClass
	public void setData() {
		excelFileName = "DisasterRecovery_CA";
		excelSheetName = 0;
		//return excelFileName;
		//return ReadExcel.readExcelData(excelFileName);
	}
	
	@Test(dataProvider="fetchData")
	public void SubmitDisasterRecoveryCA(
			String CONTEXT, String NAME
			, String Q1dot0, String Q1dot1, String Q1dot2
			, String Q2dot0, String Q2dot1, String Q2dot2
			, String Q3dot0, String Q3dot1, String Q3dot2, String Q3dot3, String Q3dot4, String Q3dot5, String Q3dot6
			
			) throws InterruptedException {
		new DisasterRecovery_CA()
		.search(CONTEXT, NAME)
		.management( Q1dot0, Q1dot1, Q1dot2)
		.governance( Q2dot0, Q2dot1, Q2dot2)
		.plandevelopment(Q3dot0, Q3dot1, Q3dot2, Q3dot3, Q3dot4, Q3dot5, Q3dot6)
		/*.clickSubmitbutton()*/
		;
		
			}
	

}
