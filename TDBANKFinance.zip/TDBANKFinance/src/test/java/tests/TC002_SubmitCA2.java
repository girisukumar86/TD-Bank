package tests;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import libraries.PSF_CA;
import pages.CAPart1;
import pages.CAPart2;
import pages.CAPart3;

public class TC002_SubmitCA2 extends PSF_CA{
	
	@BeforeClass
	public void setData() {
		excelFileName = "CA2";
		excelSheetName = 0;
		//return excelFileName;
		//return ReadExcel.readExcelData(excelFileName);
	}
	
	@Test(dataProvider="fetchData")
	public void submitCA2(
			String CONTEXT, String NAME, String Q0100, String Q0101, String Q0102, String Q0103, String Q0104, String Q0105, String Q0106, String Q0107, String Q0108, String Q0109, String Q0110, String Q0111, String Q0112, String Q0113, String Q0114, String Q0115, String Q0116, String Q0117, String Q0118
			,String Q0200, String Q0201, String Q0202, String Q0203, String Q0204, String Q0205, String Q0206, String Q0207, String Q0208, String Q0209
			,String Q0300, String Q0301, String Q0302, String Q0303, String Q0304, String Q0305, String Q0306, String Q0307, String Q0308, String Q0309
			,String Q0400, String Q0401, String Q0402, String Q0403, String Q0404, String Q0405, String Q0406, String Q0407, String Q0408, String Q0409, String Q0410, String Q0411
			,String Q0500, String Q0501, String Q0502, String Q0503, String Q0504, String Q0505, String Q0506, String Q0507, String Q0508, String Q0509
			,String Q0600, String Q0601, String Q0602, String Q0603, String Q0604, String Q0605, String Q0606, String Q0607, String Q0608
			,String Q0700, String Q0701, String Q0702, String Q0703, String Q0704, String Q0705
			,String Q0800, String Q0801, String Q0802
			,String Q0900, String Q0901, String Q0902, String Q0903, String Q0904, String Q0905, String Q0906, String Q0907, String Q0908, String Q0909, String Q0910, String Q0911, String Q0912, String Q0913
			) throws InterruptedException {
		new CAPart2()
		.search(CONTEXT, NAME)
		.encryption( Q0100,  Q0101,  Q0102,  Q0103,  Q0104,  Q0105,  Q0106,  Q0107,  Q0108,  Q0109,  Q0110,  Q0111,  Q0112,  Q0113,  Q0114,  Q0115,  Q0116,  Q0117,  Q0118)
		.website( Q0200,  Q0201,  Q0202,  Q0203,  Q0204,  Q0205,  Q0206,  Q0207,  Q0208,  Q0209)
		.systemdevelopment( Q0300,  Q0301,  Q0302,  Q0303,  Q0304,  Q0305,  Q0306,  Q0307,  Q0308,  Q0309)
		.incidentresponse( Q0400,  Q0401,  Q0402,  Q0403,  Q0404,  Q0405,  Q0406,  Q0407,  Q0408,  Q0409,  Q0410,  Q0411)
		.emailandim(Q0500,  Q0501,  Q0502,  Q0503,  Q0504,  Q0505,  Q0506,  Q0507,  Q0508,  Q0509)
		.backupandoffsitestorage(Q0600, Q0601, Q0602, Q0603, Q0604, Q0605, Q0606, Q0607, Q0608)
		.mediaandvitalrecords(Q0700,  Q0701,  Q0702,  Q0703,  Q0704,  Q0705)
		.thirdpartyrelationship(Q0800, Q0801, Q0802)
		.standardbuilds(Q0900, Q0901, Q0902, Q0903, Q0904, Q0905, Q0906, Q0907, Q0908, Q0909, Q0910, Q0911, Q0912, Q0913)		
		/*.clickSubmitbutton()*/
		;
		
			}
	

}
