package tests;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import libraries.PSF_CA;
import pages.CAPart1;
import pages.CAPart3;

public class TC002_SubmitCA3 extends PSF_CA{
	
	@BeforeClass
	public void setData() {
		excelFileName = "CA3";
		excelSheetName = 0;
		//return excelFileName;
		//return ReadExcel.readExcelData(excelFileName);
	}
	
	@Test(dataProvider="fetchData")
	public void submitCA3(
			String CONTEXT, String NAME, String Q0100, String Q0101, String Q0102, String Q0103, String Q0104, String Q0105, String Q0106, String Q0107, String Q0108, String Q0109, String Q0110, String Q0111
			,String Q0200, String Q0201, String Q0202, String Q0203, String Q0204, String Q0205, String Q0206, String Q0207, String Q0208, String Q0209, String Q0210, String Q0211, String Q0212, String Q0213, String Q0214, String Q0215, String Q0216, String Q0217, String Q0218
			,String Q0300, String Q0301, String Q0302, String Q0303, String Q0304, String Q0305, String Q0306
			,String Q0400, String Q0401, String Q0402, String Q0403, String Q0404, String Q0405, String Q0406, String Q0407, String Q0408, String Q0409, String Q0410, String Q0411, String Q0412, String Q0413, String Q0414, String Q0415, String Q0416, String Q0417, String Q0418, String Q0419, String Q0420, String Q0421, String Q0422, String Q0423, String Q0424, String Q0425, String Q0426, String Q0427, String Q0428, String Q0429, String Q0430, String Q0431, String Q0432, String Q0433, String Q0434, String Q0435, String Q0436, String Q0437, String Q0438, String Q0439, String Q0440, String Q0441, String Q0442, String Q0443, String Q0444, String Q0445, String Q0446, String Q0447, String Q0448, String Q0449, String Q0450, String Q0451, String Q0452, String Q0453, String Q0454, String Q0455, String Q0456, String Q0457, String Q0458, String Q0459, String Q0460, String Q0461, String Q0462, String Q0463, String Q0464, String Q0465, String Q0466, String Q0467, String Q0468, String Q0469, String Q0470, String Q0471, String Q0472, String Q0473
			) throws InterruptedException {
		new CAPart3()
		.search(CONTEXT, NAME)
		.application( Q0100,  Q0101,  Q0102,  Q0103,  Q0104,  Q0105,  Q0106,  Q0107,  Q0108,  Q0109,  Q0110,  Q0111)
		.vulnerabilitymonitoring( Q0200,  Q0201,  Q0202,  Q0203,  Q0204,  Q0205,  Q0206,  Q0207,  Q0208,  Q0209,  Q0210,  Q0211,  Q0212,  Q0213,  Q0214,  Q0215,  Q0216,  Q0217,  Q0218)
		.customercontact( Q0300,  Q0301,  Q0302,  Q0303,  Q0304,  Q0305,  Q0306)
		.cloudtechnology( Q0400,  Q0401,  Q0402,  Q0403,  Q0404,  Q0405,  Q0406,  Q0407,  Q0408,  Q0409,  Q0410,  Q0411,  Q0412,  Q0413,  Q0414,  Q0415,  Q0416,  Q0417,  Q0418,  Q0419,  Q0420,  Q0421,  Q0422,  Q0423,  Q0424,  Q0425,  Q0426,  Q0427,  Q0428,  Q0429,  Q0430,  Q0431,  Q0432,  Q0433,  Q0434,  Q0435,  Q0436,  Q0437,  Q0438,  Q0439,  Q0440,  Q0441,  Q0442,  Q0443,  Q0444,  Q0445,  Q0446,  Q0447,  Q0448,  Q0449,  Q0450,  Q0451,  Q0452,  Q0453,  Q0454,  Q0455,  Q0456,  Q0457,  Q0458,  Q0459,  Q0460,  Q0461,  Q0462,  Q0463,  Q0464,  Q0465,  Q0466,  Q0467,  Q0468,  Q0469,  Q0470,  Q0471,  Q0472,  Q0473)
		
		/*.clickSubmitbutton()*/
		;
		
			}
	

}
