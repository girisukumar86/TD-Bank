package tests;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import libraries.PSF_CA;
import pages.CAPart1;
import pages.Launchpad;

public class TC003_SubmitLaunchpad extends PSF_CA{
	
	@BeforeClass
	public void setData() {
		excelFileName = "Launchpad";
		excelSheetName = 0;
		//return excelFileName;
		//return ReadExcel.readExcelData(excelFileName);
	}
	
	@Test(dataProvider="fetchData")
	public void submitLP(
			String CONTEXT, String NAME, String Q1dot1, String Q3dot0
			) throws InterruptedException {
		new Launchpad()
		.search(CONTEXT, NAME)
		.LP1dot1(Q1dot1)
		.LP2dot0()
		.check(Q3dot0)
		.LP3dot0(Q3dot0)
		//.Submit()
		;
		
			}
	

}
