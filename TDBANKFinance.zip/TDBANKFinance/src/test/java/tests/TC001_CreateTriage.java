package tests;



import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import libraries.ProjectSpecificFunction;
import libraries.ReadExcel;
import pages.TriageForm;

public class TC001_CreateTriage extends ProjectSpecificFunction {
	
	
	@BeforeClass
	public void setData() {
		excelFileName = "Hiperos_TriageCreation";
		//return excelFileName;
		//return ReadExcel.readExcelData(excelFileName);
	}
	
	@Test(dataProvider="fetchData")
	public void createTriageTest(String engmName
			, String engmDesc
			, String PrimProdServOne
			, String PrimProdServTwo
			, String BusSpons
			, String LOB
			, String RiskOwner
			, String LOBs
			, String Countries
			, String CriticalActivity
			, String TargetDate
			, String ContractDate
			, String AntiSpendAmt
			, String ContrTerm
			, String SOW
			, String NBPA
			, String SpHand
			) throws InterruptedException {
		new TriageForm()
		.typeEngmName(engmName)
		.typeEngmDesc(engmDesc)
		.typePrimProdServ1(PrimProdServOne)
		//.typePrimProdServ2(PrimProdServTwo)
		.typeBusSpons(BusSpons)
		.typeLOB(LOB)
		.typeRiskOwner(RiskOwner)
		.typeLOBs(LOBs)
		.typeCountries(Countries)
		.typeCriticalActivity(CriticalActivity)
		.typeTargetDate(TargetDate)
		.typeContractDate(ContractDate)
		.typeAntiSpendAmt(AntiSpendAmt)
		.typeContrTerm(ContrTerm)
		.typeSOW(SOW)
		.typeNBPA(NBPA)
		.typeSpHand(SpHand)
		/*.clickCreatebutton()*/
		;
		
			}
	
}
