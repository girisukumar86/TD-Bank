package tests;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import libraries.PSF_CA;
import pages.CAPart1;
import pages.CAPart2;
import pages.CAPart3;
import pages.Compliance_CA;

public class TC002_SubmitComplianceCA extends PSF_CA{
	
	@BeforeClass
	public void setData() {
		excelFileName = "Compliance_CA";
		excelSheetName = 0;
		//return excelFileName;
		//return ReadExcel.readExcelData(excelFileName);
	}
	
	@Test(dataProvider="fetchData")
	public void submitcomplianceCA(
			String CONTEXT, String NAME
			, String Q2dot0, String Q2dot1, String Q2dot2, String Q2dot3
			, String Q3dot0, String Q3dot1
			,String Q4dot0, String Q4dot1, String Q4dot2
			
			) throws InterruptedException {
		new Compliance_CA()
		.search(CONTEXT, NAME)
		.complianceprogram( Q2dot0, Q2dot1, Q2dot2, Q2dot3)
		.standardofconductorcodeofethicsandtraining( Q3dot0, Q3dot1)
		.incentivecompensation( Q4dot0, Q4dot1, Q4dot2)
		/*.clickSubmitbutton()*/
		;
		
			}
	

}
