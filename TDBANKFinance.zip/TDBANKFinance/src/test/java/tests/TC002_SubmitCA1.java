package tests;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import libraries.PSF_CA;
import pages.CAPart1;

public class TC002_SubmitCA1 extends PSF_CA{
	
	@BeforeClass
	public void setData() {
		excelFileName = "CA1";
		excelSheetName = 0;
		//return excelFileName;
		//return ReadExcel.readExcelData(excelFileName);
	}
	
	@Test(dataProvider="fetchData")
	public void submitCA1(
			String CONTEXT, String NAME, String Q0100, String Q0101, String Q0102, String Q0103, String Q0104
			, String Q0200, String Q0201, String Q0202, String Q0203, String Q0204, String Q0205
			, String Q0300, String Q0301, String Q0302, String Q0303, String Q0304, String Q0305, String Q0306, String Q0307, String Q0308, String Q0309
			, String Q0400, String Q0401, String Q0402, String Q0403, String Q404, String Q0405, String Q0406
			, String Q0500, String Q0501, String Q0502
			, String Q0600, String Q0601, String Q0602, String Q0603, String Q0604, String Q0605, String Q0606, String Q0607, String Q0608, String Q0609, String Q0610, String Q0611, String Q0612
			, String Q0700, String Q0701, String Q0702, String Q0703, String Q0704, String Q0705, String Q0706, String Q0707, String Q0708, String Q0709
			, String Q0800, String Q0801, String Q0802, String Q0803, String Q0804, String Q0805
			, String Q0900, String Q0901, String Q0902, String Q0903, String Q0904, String Q0905, String Q0906, String Q0907, String Q0908, String Q0909, String Q0910, String Q0911, String Q0912, String Q0913, String Q0914, String Q0915, String Q0916
			, String Q1000, String Q1001, String Q1002, String Q1003, String Q1004
			) throws InterruptedException {
		new CAPart1()
		.search(CONTEXT, NAME)
		.riskmgmt(Q0100, Q0101, Q0102, Q0103, Q0104)
		.securitypolicy(Q0200, Q0201, Q0202, Q0203, Q0204, Q0205)
		.orgsecurity(Q0300, Q0301, Q0302, Q0303, Q0304, Q0305, Q0306, Q0307, Q0308, Q0309)
		.assetMgmt(Q0400, Q0401, Q0402, Q0403, Q404, Q0405, Q0406)
		.physicalEnv(Q0500, Q0501, Q0502)
		.commandconn(Q0600, Q0601, Q0602, Q0603, Q0604, Q0605, Q0606, Q0607, Q0608, Q0609, Q0610, Q0611, Q0612)
		.chgctrl(Q0700, Q0701, Q0702, Q0703, Q0704, Q0705, Q0706, Q0707, Q0708, Q0709)
		.operations(Q0800, Q0801, Q0802, Q0803, Q0804, Q0805)
		.logicalaccessctrl(Q0900, Q0901, Q0902, Q0903, Q0904, Q0905, Q0906, Q0907, Q0908, Q0909, Q0910, Q0911, Q0912, Q0913, Q0914, Q0915, Q0916)
		.dataintegrity(Q1000, Q1001, Q1002, Q1003, Q1004)
		
		/*.clickSubmitbutton()*/
		;
		
			}
	

}
