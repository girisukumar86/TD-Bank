package pages;

import org.openqa.selenium.Keys;

import libraries.PSF_CA;

public class CAPart2 extends PSF_CA {
	
	public CAPart2 search(String CONTEXT, String NAME) throws InterruptedException {
		//Search in Context
				driver.findElementByXPath("(//input[@class='k-input'])[4]").sendKeys(CONTEXT,Keys.ENTER);
				Thread.sleep(3000);
				//Search in Name
				driver.findElementByXPath("(//input[@class='k-input'])[1]").sendKeys(NAME,Keys.ENTER);
				Thread.sleep(4000);
				//Click View
				driver.findElementByXPath("(//a[@class='btn btn-primary'])[1]").click();
		return this;
	}
	
	public CAPart2 encryption(String Q0100, String Q0101, String Q0102, String Q0103, String Q0104, String Q0105, String Q0106, String Q0107, String Q0108, String Q0109, String Q0110, String Q0111, String Q0112, String Q0113, String Q0114, String Q0115, String Q0116, String Q0117, String Q0118) {
		driver.findElementByXPath("//div[text() [normalize-space() ='01.00']]/following::input["+Q0100+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='01.01']]/following::input["+Q0101+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='01.02']]/following::input["+Q0102+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='01.03']]/following::input["+Q0103+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='01.04']]/following::input["+Q0104+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='01.05']]/following::input["+Q0105+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='01.06']]/following::input["+Q0106+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='01.07']]/following::input["+Q0107+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='01.08']]/following::input["+Q0108+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='01.09']]/following::input["+Q0109+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='01.10']]/following::input["+Q0110+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='01.11']]/following::input["+Q0111+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='01.12']]/following::input["+Q0112+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='01.13']]/following::input["+Q0113+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='01.14']]/following::input["+Q0114+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='01.15']]/following::input["+Q0115+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='01.16']]/following::input["+Q0116+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='01.17']]/following::input["+Q0117+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='01.18']]/following::input["+Q0118+"]").click();
			
		return this;
	}
	
	public CAPart2 website(String Q0200, String Q0201, String Q0202, String Q0203, String Q0204, String Q0205, String Q0206, String Q0207, String Q0208, String Q0209) {

		driver.findElementByXPath("//div[text() [normalize-space() ='02.00']]/following::input["+Q0200+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.01']]/following::input["+Q0201+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.02']]/following::input["+Q0202+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.03']]/following::input["+Q0203+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.04']]/following::input["+Q0204+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.05']]/following::input["+Q0205+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.06']]/following::input["+Q0206+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.07']]/following::input["+Q0207+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.08']]/following::input["+Q0208+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.09']]/following::input["+Q0209+"]").click();

		return this;
	}
		
	public CAPart2 systemdevelopment(String Q0300, String Q0301, String Q0302, String Q0303, String Q0304, String Q0305, String Q0306, String Q0307, String Q0308, String Q0309) {
		driver.findElementByXPath("//div[text() [normalize-space() ='03.00']]/following::input["+Q0300+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='03.01']]/following::input["+Q0301+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='03.02']]/following::input["+Q0302+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='03.03']]/following::input["+Q0303+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='03.04']]/following::input["+Q0304+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='03.05']]/following::input["+Q0305+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='03.06']]/following::input["+Q0306+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='03.07']]/following::input["+Q0307+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='03.08']]/following::input["+Q0308+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='03.09']]/following::input["+Q0309+"]").click();
	
		return this;		
	}
	
	public CAPart2 incidentresponse(String Q0400, String Q0401, String Q0402, String Q0403, String Q0404, String Q0405, String Q0406, String Q0407, String Q0408, String Q0409, String Q0410, String Q0411) {
		driver.findElementByXPath("//div[text() [normalize-space() ='04.00']]/following::input["+Q0400+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.01']]/following::input["+Q0401+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.02']]/following::input["+Q0402+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.03']]/following::input["+Q0403+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.04']]/following::input["+Q0404+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.05']]/following::input["+Q0405+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.06']]/following::input["+Q0406+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.07']]/following::input["+Q0407+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.08']]/following::input["+Q0408+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.09']]/following::input["+Q0409+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.10']]/following::input["+Q0410+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.11']]/following::input["+Q0411+"]").click();

		return this;		
	}
	
	public CAPart2 emailandim(String Q0500, String Q0501, String Q0502, String Q0503, String Q0504, String Q0505, String Q0506, String Q0507, String Q0508, String Q0509) {
		driver.findElementByXPath("//div[text() [normalize-space() ='05.00']]/following::input["+Q0500+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='05.01']]/following::input["+Q0501+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='05.02']]/following::input["+Q0502+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='05.03']]/following::input["+Q0503+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='05.04']]/following::input["+Q0504+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='05.05']]/following::input["+Q0505+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='05.06']]/following::input["+Q0506+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='05.07']]/following::input["+Q0507+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='05.08']]/following::input["+Q0508+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='05.09']]/following::input["+Q0509+"]").click();

		return this;		
	}
	
	public CAPart2 backupandoffsitestorage(String Q0600, String Q0601, String Q0602, String Q0603, String Q0604, String Q0605, String Q0606, String Q0607, String Q0608) {
		driver.findElementByXPath("//div[text() [normalize-space() ='06.00']]/following::input["+Q0600+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='06.01']]/following::input["+Q0601+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='06.02']]/following::input["+Q0602+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='06.03']]/following::input["+Q0603+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='06.04']]/following::input["+Q0604+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='06.05']]/following::input["+Q0605+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='06.06']]/following::input["+Q0606+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='06.07']]/following::input["+Q0607+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='06.08']]/following::input["+Q0608+"]").click();

		return this;		
	}
	
	public CAPart2 mediaandvitalrecords(String Q0700, String Q0701, String Q0702, String Q0703, String Q0704, String Q0705) {
		driver.findElementByXPath("//div[text() [normalize-space() ='07.00']]/following::input["+Q0700+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='07.01']]/following::input["+Q0701+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='07.02']]/following::input["+Q0702+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='07.03']]/following::input["+Q0703+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='07.04']]/following::input["+Q0704+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='07.05']]/following::input["+Q0705+"]").click();

		return this;		
	}
	
	public CAPart2 thirdpartyrelationship(String Q0800, String Q0801, String Q0802) {
		driver.findElementByXPath("//div[text() [normalize-space() ='08.00']]/following::input["+Q0800+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='08.01']]/following::input["+Q0801+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='08.02']]/following::input["+Q0802+"]").click();

		return this;
		
		
	}
	
	public CAPart2 standardbuilds(String Q0900, String Q0901, String Q0902, String Q0903, String Q0904, String Q0905, String Q0906, String Q0907, String Q0908, String Q0909, String Q0910, String Q0911, String Q0912, String Q0913) throws InterruptedException {
		driver.findElementByXPath("//div[text() [normalize-space() ='09.00']]/following::input["+Q0900+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='09.01']]/following::input["+Q0901+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='09.02']]/following::input["+Q0902+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='09.03']]/following::input["+Q0903+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='09.04']]/following::input["+Q0904+"]").click();
		Thread.sleep(5000);
		driver.findElementByXPath("//div[text() [normalize-space() ='09.05']]/following::input["+Q0905+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='09.06']]/following::input["+Q0906+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='09.07']]/following::input["+Q0907+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='09.08']]/following::input["+Q0908+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='09.09']]/following::input["+Q0909+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='09.10']]/following::input["+Q0910+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='09.11']]/following::input["+Q0911+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='09.12']]/following::input["+Q0912+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='09.13']]/following::input["+Q0913+"]").click();

		return this;		
	}
	
}
