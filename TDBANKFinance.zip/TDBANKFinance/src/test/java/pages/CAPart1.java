package pages;

import org.openqa.selenium.Keys;

import libraries.PSF_CA;

public class CAPart1 extends PSF_CA {
	
	public CAPart1 search(String CONTEXT, String NAME) throws InterruptedException {
		//Search in Context
				driver.findElementByXPath("(//input[@class='k-input'])[4]").sendKeys(CONTEXT,Keys.ENTER);
				Thread.sleep(3000);
				//Search in Name
				driver.findElementByXPath("(//input[@class='k-input'])[1]").sendKeys(NAME,Keys.ENTER);
				Thread.sleep(4000);
				//Click View
				driver.findElementByXPath("(//a[@class='btn btn-primary'])[1]").click();
		return this;
	}
	
	public CAPart1 riskmgmt(String Q0100, String Q0101, String Q0102, String Q0103, String Q0104) {
		driver.findElementByXPath("//div[text()[normalize-space()='01.00']]/following::input["+Q0100+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='01.01']]/following::input["+Q0101+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='01.02']]/following::input["+Q0102+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='01.03']]/following::input["+Q0103+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='01.04']]/following::input["+Q0104+"]").click();
			
		return this;
	}
	
	public CAPart1 securitypolicy(String Q0200, String Q0201, String Q0202, String Q0203, String Q0204, String Q0205) {

		driver.findElementByXPath("//div[text()[normalize-space()='02.00']]/following::input["+Q0200+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='02.01']]/following::input["+Q0201+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='02.02']]/following::input["+Q0202+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='02.03']]/following::input["+Q0203+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='02.04']]/following::input["+Q0204+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='02.05']]/following::input["+Q0205+"]").click();
		
		return this;
	}
		
	public CAPart1 orgsecurity(String Q0300, String Q0301, String Q0302, String Q0303, String Q0304, String Q0305, String Q0306, String Q0307, String Q0308, String Q0309) {
		driver.findElementByXPath("//div[text()[normalize-space()='03.00']]/following::input["+Q0300+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='03.01']]/following::input["+Q0301+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='03.02']]/following::input["+Q0302+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='03.03']]/following::input["+Q0303+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='03.04']]/following::input["+Q0304+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='03.05']]/following::input["+Q0305+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='03.06']]/following::input["+Q0306+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='03.07']]/following::input["+Q0307+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='03.08']]/following::input["+Q0308+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='03.09']]/following::input["+Q0309+"]").click();
		
		return this;		
	}
	
	public CAPart1 assetMgmt(String Q0400, String Q0401, String Q0402, String Q0403, String Q404, String Q0405, String Q0406) {
		driver.findElementByXPath("//div[text()[normalize-space()='04.00']]/following::input["+Q0400+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='04.01']]/following::input["+Q0401+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='04.02']]/following::input["+Q0402+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='04.03']]/following::input["+Q0403+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='04.04']]/following::input["+Q404+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='04.05']]/following::input["+Q0405+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='04.06']]/following::input["+Q0406+"]").click();
		
		return this;		
	}
	
	public CAPart1 physicalEnv(String Q0500, String Q0501, String Q0502) {
		driver.findElementByXPath("//div[text()[normalize-space()='05.00']]/following::input["+Q0500+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='05.01']]/following::input["+Q0501+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='05.02']]/following::input["+Q0502+"]").click();
		return this;		
	}	
		
	public CAPart1 commandconn(String Q0600, String Q0601, String Q0602, String Q0603, String Q0604, String Q0605, String Q0606, String Q0607, String Q0608, String Q0609, String Q0610, String Q0611, String Q0612) {
		driver.findElementByXPath("//div[text()[normalize-space()='06.00']]/following::input["+Q0600+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='06.01']]/following::input["+Q0601+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='06.02']]/following::input["+Q0602+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='06.03']]/following::input["+Q0603+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='06.04']]/following::input["+Q0604+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='06.05']]/following::input["+Q0605+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='06.06']]/following::input["+Q0606+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='06.07']]/following::input["+Q0607+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='06.08']]/following::input["+Q0608+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='06.09']]/following::input["+Q0609+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='06.10']]/following::input["+Q0610+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='06.11']]/following::input["+Q0611+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='06.12']]/following::input["+Q0612+"]").click();
		
		return this;		
	}
	
	public CAPart1 chgctrl(String Q0700, String Q0701, String Q0702, String Q0703, String Q0704, String Q0705, String Q0706, String Q0707, String Q0708, String Q0709) {
        driver.findElementByXPath("//div[text()[normalize-space()='07.00']]/following::input["+Q0700+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='07.01']]/following::input["+Q0701+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='07.02']]/following::input["+Q0702+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='07.03']]/following::input["+Q0703+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='07.04']]/following::input["+Q0704+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='07.05']]/following::input["+Q0705+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='07.06']]/following::input["+Q0706+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='07.07']]/following::input["+Q0707+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='07.08']]/following::input["+Q0708+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space()='07.09']]/following::input["+Q0709+"]").click();
		return this;	
	}
		
		public CAPart1 operations(String Q0800, String Q0801, String Q0802, String Q0803, String Q0804, String Q0805) {
			driver.findElementByXPath("//div[text()[normalize-space()='08.00']]/following::input["+Q0800+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='08.01']]/following::input["+Q0801+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='08.02']]/following::input["+Q0802+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='08.03']]/following::input["+Q0803+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='08.04']]/following::input["+Q0804+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='08.05']]/following::input["+Q0805+"]").click();
			
			return this;	
	}

		public CAPart1 logicalaccessctrl(String Q0900, String Q0901, String Q0902, String Q0903, String Q0904, String Q0905, String Q0906, String Q0907, String Q0908, String Q0909, String Q0910, String Q0911, String Q0912, String Q0913, String Q0914, String Q0915, String Q0916) {
			driver.findElementByXPath("//div[text()[normalize-space()='09.00']]/following::input["+Q0900+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='09.01']]/following::input["+Q0901+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='09.02']]/following::input["+Q0902+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='09.03']]/following::input["+Q0903+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='09.04']]/following::input["+Q0904+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='09.05']]/following::input["+Q0905+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='09.06']]/following::input["+Q0906+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='09.07']]/following::input["+Q0907+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='09.08']]/following::input["+Q0908+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='09.09']]/following::input["+Q0909+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='09.10']]/following::input["+Q0910+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='09.11']]/following::input["+Q0911+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='09.12']]/following::input["+Q0912+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='09.13']]/following::input["+Q0913+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='09.14']]/following::input["+Q0914+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='09.15']]/following::input["+Q0915+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='09.16']]/following::input["+Q0916+"]").click();
			
			return this;	
	}

		public CAPart1 dataintegrity(String Q1000, String Q1001, String Q1002, String Q1003, String Q1004) {
			driver.findElementByXPath("//div[text()[normalize-space()='10.00']]/following::input["+Q1000+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='10.01']]/following::input["+Q1001+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='10.02']]/following::input["+Q1002+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='10.03']]/following::input["+Q1003+"]").click();
			driver.findElementByXPath("//div[text()[normalize-space()='10.04']]/following::input["+Q1004+"]").click();
			return this;	
	}

		


}
