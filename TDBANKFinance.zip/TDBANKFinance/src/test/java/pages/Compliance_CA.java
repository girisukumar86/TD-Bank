package pages;

import org.openqa.selenium.Keys;

import libraries.PSF_CA;

public class Compliance_CA extends PSF_CA {
	
	public Compliance_CA search(String CONTEXT, String NAME) throws InterruptedException {
		//Search in Context
				driver.findElementByXPath("(//input[@class='k-input'])[4]").sendKeys(CONTEXT,Keys.ENTER);
				Thread.sleep(3000);
				//Search in Name
				driver.findElementByXPath("(//input[@class='k-input'])[1]").sendKeys(NAME,Keys.ENTER);
				Thread.sleep(4000);
				//Click View
				driver.findElementByXPath("(//a[@class='btn btn-primary'])[1]").click();
		return this;
	}
	
	public Compliance_CA complianceprogram(String Q2dot0, String Q2dot1, String Q2dot2, String Q2dot3) {
		driver.findElementByXPath("//*[text() [normalize-space()='2.0']]/following::input["+Q2dot0+"]").click();
		driver.findElementByXPath("//*[text() [normalize-space()='2.1']]/following::input["+Q2dot1+"]").click();
		driver.findElementByXPath("//*[text() [normalize-space()='2.2']]/following::input["+Q2dot2+"]").click();
		driver.findElementByXPath("//*[text() [normalize-space()='2.3']]/following::input["+Q2dot3+"]").click();
		
		return this;
	}
	
	public Compliance_CA standardofconductorcodeofethicsandtraining(String Q3dot0, String Q3dot1) {

		driver.findElementByXPath("//*[text() [normalize-space()='3.0']]/following::input["+Q3dot0+"]").click();
		driver.findElementByXPath("//*[text() [normalize-space()='3.1']]/following::input["+Q3dot1+"]").click();
		
		return this;
	}
		
	public Compliance_CA incentivecompensation(String Q4dot0, String Q4dot1, String Q4dot2) {
		driver.findElementByXPath("//*[text() [normalize-space()='4.0']]/following::input["+Q4dot0+"]").click();
		driver.findElementByXPath("//*[text() [normalize-space()='4.1']]/following::input["+Q4dot1+"]").click();
		driver.findElementByXPath("//*[text() [normalize-space()='4.2']]/following::input["+Q4dot2+"]").click();
	
		return this;		
	}
		
}
