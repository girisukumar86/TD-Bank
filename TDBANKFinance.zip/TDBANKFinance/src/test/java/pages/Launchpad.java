package pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import libraries.PSF_CA;

public class Launchpad extends PSF_CA {
	
	public Launchpad search(String CONTEXT, String NAME) throws InterruptedException {
		//Search in Context
				driver.findElementByXPath("(//input[@class='k-input'])[4]").sendKeys(CONTEXT,Keys.ENTER);
				Thread.sleep(3000);
				//Search in Name
				driver.findElementByXPath("(//input[@class='k-input'])[1]").sendKeys(NAME,Keys.ENTER);
				Thread.sleep(4000);
				//Click View
				driver.findElementByXPath("(//a[@class='btn btn-primary'])[1]").click();
		return this;
	}
	
	public Launchpad LP1dot1(String Q1dot1) throws InterruptedException {
		WebElement q1dot1 = driver.findElementByXPath("//*[text()[normalize-space()='1.1']]/following::select");
		new Select(q1dot1).selectByVisibleText(Q1dot1);
		Thread.sleep(4000);
		
		return this;
	}
	
	public Launchpad LP2dot0() throws InterruptedException {
		WebElement Overallriskrating = driver.findElementByXPath("//div[contains(text(),'Risk Rating')]/following::div");
		String LP2dot0_1 = Overallriskrating.getText();
		System.out.println("Overallriskrating:"+LP2dot0_1);
		
		WebElement CArating = driver.findElementByXPath("//*[text()[normalize-space()='2.0']]/following::td[2]");
		String LP2dot0_2 = CArating.getText();
		System.out.println("CA Rating:"+LP2dot0_2);
		
		WebElement CAstatus = driver.findElementByXPath("//*[text()[normalize-space()='2.0']]/following::td[4]");
		String LP2dot0_3 = CAstatus.getText();
		System.out.println("CA Status:"+LP2dot0_3);
		
		WebElement CAdate = driver.findElementByXPath("//*[text()[normalize-space()='2.0']]/following::td[6]");
		String LP2dot0_4 = CAdate.getText();
		System.out.println("CA Status:"+LP2dot0_4);			
		Thread.sleep(2000);
		
		return this;
	}
	
	public Launchpad check(String Q3dot0) throws InterruptedException {
		
		WebElement CAstatus1 = driver.findElementByXPath("//*[text()[normalize-space()='2.0']]/following::td[2]");
		String LP2dot0_5 = CAstatus1.getText();
		System.out.println(LP2dot0_5);
		System.out.println(Q3dot0);
		Assert.assertFalse(LP2dot0_5.contains("CA Not Available") && Q3dot0.equals("4"));
		Thread.sleep(2000);
		
		return this;
	}
	
	public Launchpad LP3dot0(String Q3dot0) throws InterruptedException {
		driver.findElementByXPath("//*[text()[normalize-space()='3.0']]/following::input["+Q3dot0+"]").click();
		driver.findElementByXPath("//*[text()[normalize-space()='3.0']]/following::textarea").sendKeys("SIT test");
		Thread.sleep(5000);
		
		return this;
	}
	
	public Launchpad Submit() throws InterruptedException {
		driver.findElementByXPath("//button[@id='btnFloatInitiateSubmit']").click();
		Thread.sleep(5000);
		
		return this;
	}
	
}
