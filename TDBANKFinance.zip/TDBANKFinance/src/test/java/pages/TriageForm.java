package pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import libraries.ProjectSpecificFunction;

public class TriageForm extends ProjectSpecificFunction {
	
	public TriageForm typeEngmName(String engmName) {
		driver.findElementByXPath("((//*[text()='Engagement Name'])[2]/following::input)[1]")
		.sendKeys(engmName);
		//Thread.sleep(2000);	
		return this;
	}
	
	public TriageForm typeEngmDesc(String engmDesc) {
		driver.findElementByXPath("((//*[text()='Engagement Description'])[2]/following::textarea)[1]")
		.sendKeys(engmDesc);
		//Thread.sleep(2000);	
		return this;
	}
	
	public TriageForm typePrimProdServ1(String PrimProdServOne) throws InterruptedException {
		driver.findElementByXPath("((//*[text()='Product/Service'])[2]//following::a)[1]")
		.click();
		driver.findElementByXPath("(//label[text()='New page name:']/following::input)[5]")
		.sendKeys(PrimProdServOne);
		//Thread.sleep(2000);
		driver.findElementByXPath("(//label[text()='New page name:']/following::input)[5]")
		.sendKeys(Keys.ENTER);	
		return this;
	}
	
	public TriageForm typePrimProdServ2(String PrimProdServTwo) {
		driver.findElementByXPath("((//*[text()='Product/Service'])[2]//following::a)[3]")
		.click();
		//Thread.sleep(2000);
		driver.findElementByXPath("//input[@class='select2-input select2-focused']")
		.sendKeys(PrimProdServTwo);
		//Thread.sleep(2000);
		driver.findElementByXPath("//input[@class='select2-input select2-focused']")
		.sendKeys(Keys.ENTER);	
		return this;
	}
		
	public TriageForm typeBusSpons(String BusSpons) {
		driver.findElementByXPath("((//*[text()='Business Sponsor'])[2]//following::a)[2]")
		.click();
		driver.findElementByXPath("//input[@class='select2-input select2-focused']")
		.sendKeys(BusSpons);
		//Thread.sleep(2000);
		driver.findElementByXPath("//input[@class='select2-input select2-focused']")
		.sendKeys(Keys.ENTER);	
		return this;	
	}
	
	public TriageForm typeLOB(String LOB) {
		driver.findElementByXPath("((//*[text()='LOB owning the Product/Service'])[2]//following::a)[1]")
		.click();
		driver.findElementByXPath("//input[@class='select2-input select2-focused']")
		.sendKeys(LOB);
		//Thread.sleep(2000);
		driver.findElementByXPath("//input[@class='select2-input select2-focused']")
		.sendKeys(Keys.ENTER);			
		return this;	
	}
	
	public TriageForm typeRiskOwner(String RiskOwner) {
		driver.findElementByXPath("((//*[text()='Risk Owner Approver'])[2]//following::a)[2]")
		.click();
		driver.findElementByXPath("//input[@class='select2-input select2-focused']")
		.sendKeys(RiskOwner);
		//Thread.sleep(2000);
		driver.findElementByXPath("//input[@class='select2-input select2-focused']")
		.sendKeys(Keys.ENTER);				
		return this;	
	}
	
	public TriageForm typeLOBs(String LOBs) {
		driver.findElementByXPath("((//*[text()='LOB(s) receiving Products/Services'])[2]/following::input)[1]")
		.sendKeys(LOBs);
		driver.findElementByXPath("(//span[@bo-text='option.display'])[1]")
		.click();				
		return this;	
	}
	
	public TriageForm typeCountries(String Countries) throws InterruptedException {
		driver.findElementByXPath("((//*[text()='Countries receiving the Products /Services'])[2]/following::input)[1]")
		.sendKeys(Countries);
		//Thread.sleep(2000);
		driver.findElementByXPath("((//*[text()='Countries receiving the Products /Services'])[2]/following::a)[2]")
		.click();		
		return this;	
	}
	
	public TriageForm typeCriticalActivity(String CriticalActivity) throws InterruptedException {
		driver.findElementByXPath("((//*[text()='Critical Activity Type(s)'])[2]/following::input)[1]")
		.sendKeys(CriticalActivity);
		//Thread.sleep(2000);
		driver.findElementByXPath("((//*[text()='Critical Activity Type(s)'])[2]/following::a)[2]")
		.click();			
		return this;	
	}
	
	public TriageForm typeTargetDate(String TargetDate) {
		driver.findElementByXPath("((//*[text()='Target Contract Sign Date'])[2]/following::input)[1]")
		.sendKeys(TargetDate);			
		return this;	
	}

	public TriageForm typeContractDate(String ContractDate) {
		driver.findElementByXPath("((//*[text()='Planned Contract Length (months)'])[2]/following::input)[1]")
		.sendKeys(ContractDate);		
		return this;	
	}
	
	public TriageForm typeAntiSpendAmt(String AntiSpendAmt) {
		driver.findElementByXPath("((//*[text()='Anticipated Spend'])[2]/following::input)[1]")
		.sendKeys(AntiSpendAmt);		
		return this;	
	}	
	
	public TriageForm typeContrTerm(String ContrTerm) {
		WebElement contract_termination = driver.findElementByXPath("((//*[text()='Contract Termination?'])[2]/following::select)[1]");
		new Select(contract_termination)
		.selectByVisibleText(ContrTerm);	
		return this;	
	}	
	
	public TriageForm typeSOW(String SOW) {
		driver.findElementByXPath("((//*[text()='Is this a change to an existing Statement of Work (SOW) or Work Order?'])[2]/following::a)[2]")
		.click();
		WebElement SOW1 = driver.findElementByXPath("//input[@class='select2-input select2-focused']");
		SOW1.sendKeys(SOW);
		SOW1.sendKeys(Keys.ENTER);			
		return this;	
	}
	
	public TriageForm typeNBPA(String NBPA) {
		driver.findElementByXPath("((//*[text()='Third Party services for a new business product or new service (NBPA)?'])[2]/following::a)[2]")
		.click();
		WebElement NBPA1 = driver.findElementByXPath("//input[@class='select2-input select2-focused']");
		NBPA1.sendKeys(NBPA);
		NBPA1.sendKeys(Keys.ENTER);		
		return this;	
	}
	
	public TriageForm typeSpHand(String SpHand) {
		driver.findElementByXPath("((//*[text()='Special Handling'])[2]/following::input)[1]")
		.sendKeys(SpHand);
		driver.findElementByXPath("((//*[text()='Special Handling'])[2]/following::a)[2]")
		.click();			
		return this;	
	}
	
	/*public TriageForm clickCreatebutton() throws InterruptedException {
		driver.findElementByXPath("//i[@class='icon-white icon-ok']/following-sibling::strong[1]")
		.click();
		Thread.sleep(10000);
		driver.switchTo().alert().accept();			
		return this;
	}*/
	
	
	
	
}
