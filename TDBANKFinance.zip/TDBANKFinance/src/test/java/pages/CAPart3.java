package pages;

import org.openqa.selenium.Keys;

import libraries.PSF_CA;

public class CAPart3 extends PSF_CA {
	
	public CAPart3 search(String CONTEXT, String NAME) throws InterruptedException {
		//Search in Context
				driver.findElementByXPath("(//input[@class='k-input'])[4]").sendKeys(CONTEXT,Keys.ENTER);
				Thread.sleep(3000);
				//Search in Name
				driver.findElementByXPath("(//input[@class='k-input'])[1]").sendKeys(NAME,Keys.ENTER);
				Thread.sleep(4000);
				//Click View
				driver.findElementByXPath("(//a[@class='btn btn-primary'])[1]").click();
		return this;
	}
	
	public CAPart3 application(String Q0100, String Q0101, String Q0102, String Q0103, String Q0104, String Q0105, String Q0106, String Q0107, String Q0108, String Q0109, String Q0110, String Q0111) {
		driver.findElementByXPath("//div[text()[normalize-space() ='01.00']]/following::input["+Q0100+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space() ='01.01']]/following::input["+Q0101+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space() ='01.02']]/following::input["+Q0102+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space() ='01.03']]/following::input["+Q0103+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space() ='01.04']]/following::input["+Q0104+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space() ='01.05']]/following::input["+Q0105+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space() ='01.06']]/following::input["+Q0106+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space() ='01.07']]/following::input["+Q0107+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space() ='01.08']]/following::input["+Q0108+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space() ='01.09']]/following::input["+Q0109+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space() ='01.10']]/following::input["+Q0110+"]").click();
		driver.findElementByXPath("//div[text()[normalize-space() ='01.11']]/following::input["+Q0111+"]").click();
			
		return this;
	}
	
	public CAPart3 vulnerabilitymonitoring(String Q0200, String Q0201, String Q0202, String Q0203, String Q0204, String Q0205, String Q0206, String Q0207, String Q0208, String Q0209, String Q0210, String Q0211, String Q0212, String Q0213, String Q0214, String Q0215, String Q0216, String Q0217, String Q0218) {

		driver.findElementByXPath("//div[text() [normalize-space() ='02.00']]/following::input["+Q0200+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.01']]/following::input["+Q0201+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.02']]/following::input["+Q0202+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.03']]/following::input["+Q0203+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.04']]/following::input["+Q0204+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.05']]/following::input["+Q0205+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.06']]/following::input["+Q0206+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.07']]/following::input["+Q0207+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.08']]/following::input["+Q0208+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.09']]/following::input["+Q0209+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.10']]/following::input["+Q0210+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.11']]/following::input["+Q0211+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.12']]/following::input["+Q0212+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.13']]/following::input["+Q0213+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.14']]/following::input["+Q0214+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.15']]/following::input["+Q0215+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.16']]/following::input["+Q0216+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.17']]/following::input["+Q0217+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='02.18']]/following::input["+Q0218+"]").click();
		
		return this;
	}
		
	public CAPart3 customercontact(String Q0300, String Q0301, String Q0302, String Q0303, String Q0304, String Q0305, String Q0306) {
		driver.findElementByXPath("//div[text() [normalize-space() ='03.00']]/following::input["+Q0300+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='03.01']]/following::input["+Q0301+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='03.02']]/following::input["+Q0302+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='03.03']]/following::input["+Q0303+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='03.04']]/following::input["+Q0304+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='03.05']]/following::input["+Q0305+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='03.06']]/following::input["+Q0306+"]").click();
			
		return this;		
	}
	
	public CAPart3 cloudtechnology(String Q0400, String Q0401, String Q0402, String Q0403, String Q0404, String Q0405, String Q0406, String Q0407, String Q0408, String Q0409, String Q0410, String Q0411, String Q0412, String Q0413, String Q0414, String Q0415, String Q0416, String Q0417, String Q0418, String Q0419, String Q0420, String Q0421, String Q0422, String Q0423, String Q0424, String Q0425, String Q0426, String Q0427, String Q0428, String Q0429, String Q0430, String Q0431, String Q0432, String Q0433, String Q0434, String Q0435, String Q0436, String Q0437, String Q0438, String Q0439, String Q0440, String Q0441, String Q0442, String Q0443, String Q0444, String Q0445, String Q0446, String Q0447, String Q0448, String Q0449, String Q0450, String Q0451, String Q0452, String Q0453, String Q0454, String Q0455, String Q0456, String Q0457, String Q0458, String Q0459, String Q0460, String Q0461, String Q0462, String Q0463, String Q0464, String Q0465, String Q0466, String Q0467, String Q0468, String Q0469, String Q0470, String Q0471, String Q0472, String Q0473) {
		driver.findElementByXPath("//div[text() [normalize-space() ='04.00']]/following::input["+Q0400+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.01']]/following::input["+Q0401+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.02']]/following::input["+Q0402+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.03']]/following::input["+Q0403+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.04']]/following::input["+Q0404+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.05']]/following::input["+Q0405+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.06']]/following::input["+Q0406+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.07']]/following::input["+Q0407+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.08']]/following::input["+Q0408+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.09']]/following::input["+Q0409+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.10']]/following::input["+Q0410+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.11']]/following::input["+Q0411+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.12']]/following::input["+Q0412+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.13']]/following::input["+Q0413+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.14']]/following::input["+Q0414+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.15']]/following::input["+Q0415+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.16']]/following::input["+Q0416+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.17']]/following::input["+Q0417+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.18']]/following::input["+Q0418+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.19']]/following::input["+Q0419+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.20']]/following::input["+Q0420+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.21']]/following::input["+Q0421+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.22']]/following::input["+Q0422+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.23']]/following::input["+Q0423+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.24']]/following::input["+Q0424+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.25']]/following::input["+Q0425+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.26']]/following::input["+Q0426+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.27']]/following::input["+Q0427+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.28']]/following::input["+Q0428+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.29']]/following::input["+Q0429+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.30']]/following::input["+Q0430+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.31']]/following::input["+Q0431+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.32']]/following::input["+Q0432+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.33']]/following::input["+Q0433+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.34']]/following::input["+Q0434+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.35']]/following::input["+Q0435+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.36']]/following::input["+Q0436+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.37']]/following::input["+Q0437+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.38']]/following::input["+Q0438+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.39']]/following::input["+Q0439+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.40']]/following::input["+Q0440+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.41']]/following::input["+Q0441+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.42']]/following::input["+Q0442+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.43']]/following::input["+Q0443+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.44']]/following::input["+Q0444+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.45']]/following::input["+Q0445+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.46']]/following::input["+Q0446+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.47']]/following::input["+Q0447+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.48']]/following::input["+Q0448+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.49']]/following::input["+Q0449+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.50']]/following::input["+Q0450+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.51']]/following::input["+Q0451+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.52']]/following::input["+Q0452+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.53']]/following::input["+Q0453+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.54']]/following::input["+Q0454+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.55']]/following::input["+Q0455+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.56']]/following::input["+Q0456+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.57']]/following::input["+Q0457+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.58']]/following::input["+Q0458+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.59']]/following::input["+Q0459+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.60']]/following::input["+Q0460+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.61']]/following::input["+Q0461+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.62']]/following::input["+Q0462+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.63']]/following::input["+Q0463+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.64']]/following::input["+Q0464+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.65']]/following::input["+Q0465+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.66']]/following::input["+Q0466+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.67']]/following::input["+Q0467+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.68']]/following::input["+Q0468+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.69']]/following::input["+Q0469+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.70']]/following::input["+Q0470+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.71']]/following::input["+Q0471+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.72']]/following::input["+Q0472+"]").click();
		driver.findElementByXPath("//div[text() [normalize-space() ='04.73']]/following::input["+Q0473+"]").click();

		return this;		
	}
	
	
}
