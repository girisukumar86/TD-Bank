package pages;

import org.openqa.selenium.Keys;

import libraries.PSF_CA;

public class DisasterRecovery_CA extends PSF_CA {
	
	public DisasterRecovery_CA search(String CONTEXT, String NAME) throws InterruptedException {
		//Search in Context
				driver.findElementByXPath("(//input[@class='k-input'])[4]").sendKeys(CONTEXT,Keys.ENTER);
				Thread.sleep(3000);
				//Search in Name
				driver.findElementByXPath("(//input[@class='k-input'])[1]").sendKeys(NAME,Keys.ENTER);
				Thread.sleep(4000);
				//Click View
				driver.findElementByXPath("(//a[@class='btn btn-primary'])[1]").click();
		return this;
	}
	
	public DisasterRecovery_CA management(String Q1dot0, String Q1dot1, String Q1dot2) {
		driver.findElementByXPath("//*[text() [normalize-space()='1.0']]/following::input["+Q1dot0+"]").click();
		driver.findElementByXPath("//*[text() [normalize-space()='1.1']]/following::input["+Q1dot1+"]").click();
		driver.findElementByXPath("//*[text() [normalize-space()='1.2']]/following::input["+Q1dot2+"]").click();
				
		return this;
	}
	
	public DisasterRecovery_CA governance(String Q2dot0, String Q2dot1, String Q2dot2) {
		driver.findElementByXPath("//*[text() [normalize-space()='2.0']]/following::input["+Q2dot0+"]").click();
		driver.findElementByXPath("//*[text() [normalize-space()='2.1']]/following::input["+Q2dot1+"]").click();
		driver.findElementByXPath("//*[text() [normalize-space()='2.2']]/following::input["+Q2dot2+"]").click();
				
		return this;
	}
		
	public DisasterRecovery_CA plandevelopment(String Q3dot0, String Q3dot1, String Q3dot2, String Q3dot3, String Q3dot4, String Q3dot5, String Q3dot6) {
		driver.findElementByXPath("//*[text() [normalize-space()='3.0']]/following::input["+Q3dot0+"]").click();
		driver.findElementByXPath("//*[text() [normalize-space()='3.1']]/following::input["+Q3dot1+"]").click();
		driver.findElementByXPath("//*[text() [normalize-space()='3.2']]/following::input["+Q3dot2+"]").click();
		driver.findElementByXPath("//*[text() [normalize-space()='3.3']]/following::input["+Q3dot3+"]").click();
		driver.findElementByXPath("//*[text() [normalize-space()='3.4']]/following::input["+Q3dot4+"]").click();
		driver.findElementByXPath("//*[text() [normalize-space()='3.5']]/following::input["+Q3dot5+"]").click();
		driver.findElementByXPath("//*[text() [normalize-space()='3.6']]/following::input["+Q3dot6+"]").click();
	
		return this;		
	}
		
}
