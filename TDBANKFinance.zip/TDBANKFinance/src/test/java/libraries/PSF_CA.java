package libraries;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

public class PSF_CA {
	public static String excelFileName;
	public static int excelSheetName;
	public static ChromeDriver driver;
	
	//public static String LID;
	//public static String engmName, engmDesc, PrimProdServOne, PrimProdServTwo, BusSpons, LOB, RiskOwner, LOBs, Countries, CriticalActivity, TargetDate, ContractDate, AntiSpendAmt, ContrTerm, SOW, NBPA, SpHand;
	@Parameters({"url", "username", "password"})
	@BeforeMethod
	public void login(String URL, String uname, String PASSWORD) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(URL);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElementByXPath("//input[@id='txtUsername']").sendKeys(uname);
		driver.findElementByXPath("//input[@class='signin-password']").sendKeys(PASSWORD);
		driver.findElementByXPath("//input[@id='btnLogin']").click();
		
		//Click Show me All under Evaluations
		driver.findElementByXPath("(//div[@class='hiperos_localizable'])[1]").click();
		Thread.sleep(2000);
		/*//Search in Context
		driver.findElementByXPath("(//input[@class='k-input'])[4]").sendKeys("Wave2_SIT_30_SP",Keys.ENTER);
		Thread.sleep(3000);
		//Search in Name
		driver.findElementByXPath("(//input[@class='k-input'])[1]").sendKeys("Cyber and InfoSec 3PCRQ Control Assessment Part 1",Keys.ENTER);
		Thread.sleep(4000);
		//Click View
		driver.findElementByXPath("(//a[@class='btn btn-primary'])[1]").click();
		*/
	}
	
	@AfterMethod
	//public void closeBrowser() {
		//driver.close();

	//}
	
	@DataProvider(name="fetchData")
	public String[][] getData() throws IOException {
		return ReadExcel.readExcelData(excelFileName, excelSheetName);
	}
}