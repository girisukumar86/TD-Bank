package libraries;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;


public class ProjectSpecificFunction  {
	public static String excelFileName;
	public static ChromeDriver driver;
	//public static String LID;
	//public static String engmName, engmDesc, PrimProdServOne, PrimProdServTwo, BusSpons, LOB, RiskOwner, LOBs, Countries, CriticalActivity, TargetDate, ContractDate, AntiSpendAmt, ContrTerm, SOW, NBPA, SpHand;
	@Parameters({"url", "username", "password"})
	@BeforeMethod
	public void login(String URL, String uname, String PASSWORD) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(URL);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElementByXPath("//input[@id='txtUsername']").sendKeys(uname);
		driver.findElementByXPath("//input[@class='signin-password']").sendKeys(PASSWORD);
		driver.findElementByXPath("//input[@id='btnLogin']").click();
		
		//Click Personal
		driver.findElementByXPath("(//a[@class='hiperos_localizable'])[2]").click();//Triage Form Opens
	}
	
	@AfterMethod
	public void closeBrowser() {
		//driver.close();

	}
	
	@DataProvider(name="fetchData")
	public String[][] getData() throws IOException {
		return ReadExcel.readExcelData(excelFileName);
	}
}