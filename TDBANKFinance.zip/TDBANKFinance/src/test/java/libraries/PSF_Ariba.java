package libraries;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;


public class PSF_Ariba  {
	public static String excelFileName;
	public static ChromeDriver driver;
	//public static String LID;
	//public static String engmName, engmDesc, PrimProdServOne, PrimProdServTwo, BusSpons, LOB, RiskOwner, LOBs, Countries, CriticalActivity, TargetDate, ContractDate, AntiSpendAmt, ContrTerm, SOW, NBPA, SpHand;
	@Parameters({"url", "username", "password"})
	@BeforeMethod
	public void login(String URL, String uname, String PASSWORD) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(URL);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElementById("UserName").sendKeys(uname);
		driver.findElementById("Password").sendKeys(PASSWORD);
		driver.findElementByXPath("//input[@type='submit']").click();
		
		//Click Personal
		driver.findElementByXPath("//div[@class='a-mastCmd-create-button']//span[1]").click();
		driver.findElementByXPath("//a[@title='Sourcing Request']").click();
	}
	
	@AfterMethod
	public void closeBrowser() {
		driver.close();

	}
	
	@DataProvider(name="fetchData")
	public String[][] getData() throws IOException {
		return ReadExcel.readExcelData(excelFileName);
	}
}